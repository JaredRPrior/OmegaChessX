//
//  File.swift
//  SwiftChessExample
//
//  Created by Jared Prior on 8/27/20.
//  Copyright © 2020 CocoaPods. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    @IBAction func loginPressed(_ sender: Any) {
        self.performSegue(withIdentifier: "logInSegue", sender: self)
        print("button pressed!")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        print("View has loaded")
    }
}
