//
//  SwiftChess.h
//  SwiftChess
//
//  Created by Steve Barnegren on 23/11/2016.
//  Copyright © 2016 Steve Barnegren. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SwiftChess.
FOUNDATION_EXPORT double SwiftChessVersionNumber;

//! Project version string for SwiftChess.
FOUNDATION_EXPORT const unsigned char SwiftChessVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftChess/PublicHeader.h>


